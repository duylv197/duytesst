for i in range(3):
    print('This is loop number', i + 1)