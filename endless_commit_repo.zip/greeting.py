name = "Endless Airdrop"
print(f"Hello, {name}!")