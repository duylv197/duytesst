import datetime

print('Current time:', datetime.datetime.now())