import random

nums = [random.randint(1, 100) for _ in range(5)]
print('Random numbers:', nums)