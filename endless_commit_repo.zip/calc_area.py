def area_circle(r):
    return 3.14 * r * r

print(area_circle(3))