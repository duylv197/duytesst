def add(a, b):
    return a + b

print(add(5, 7))